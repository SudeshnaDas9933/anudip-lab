package org.anudip.hibernateLabApplication.application;
import java.util.Scanner;

import org.anudip.hibernateLabApplication.bean.Result;
import org.anudip.hibernateLabApplication.bean.ResultService;
import org.anudip.hibernateLabApplication.bean.Student;
import org.anudip.hibernateLabApplication.bean.StudentNotFoundException;
import org.anudip.hibernateLabApplication.dao.DatabaseHandler;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentMain {
	public static void insertRecord() {
		// Implement logic to insert student's details
		try {
			Session session = DatabaseHandler.getDatabaseHandler().createSession();
			Transaction transaction = session.beginTransaction();

			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter Roll Number: ");
			String rollNumber = scanner.nextLine();
			System.out.print("Enter Student Name: ");
			String studentName = scanner.nextLine();
			System.out.print("Enter Semester: ");
			String semester = scanner.nextLine();
			System.out.print("Enter Half-Yearly Total: ");
			double halfYearlyTotal = Double.parseDouble(scanner.nextLine());

			Result result = new Result();
			result.setRollNumber(rollNumber);
			result.setHalfYearlyTotal(halfYearlyTotal);
			Student student = new Student(rollNumber, studentName, semester, result);

			session.save(student);
			transaction.commit();
			session.close();
			scanner.close();
			System.out.println("Student record added successfully.");
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}// end of insert method

	public static void updateRecord() {
		// Implement logic to update a student's record in the Result table
		try {
			Session session = DatabaseHandler.getDatabaseHandler().createSession();
			Transaction transaction = session.beginTransaction();

			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter Roll Number: ");
			String rollNumber = scanner.nextLine();

			Student student = session.get(Student.class, rollNumber);

			if (student == null) {
				throw new StudentNotFoundException("Student with Roll Number " + rollNumber + " not found.");
			}
			System.out.println("Enter the marks of English");
			double englishMarks = Double.parseDouble(scanner.nextLine());
			System.out.println("Enter the marks of Language");
			double languageMarks = Double.parseDouble(scanner.nextLine());
			System.out.println("Enter the marks of Math");
			double mathMarks = Double.parseDouble(scanner.nextLine());
			System.out.println("Enter the marks of Science");
			double scienceMarks = Double.parseDouble(scanner.nextLine());
			System.out.println("Enter the marks of Social Study");
			double socialMarks = Double.parseDouble(scanner.nextLine());

			double annualTotal = englishMarks + languageMarks + mathMarks + scienceMarks + socialMarks;

			Result result = student.getStudentResult();
			result.setAnnualTotal(annualTotal);

			// Calculate grade using ResultService class
			String grade = ResultService.gradeCalculation(result);
			result.setGrade(grade);

			session.saveOrUpdate(result);
			transaction.commit();
			session.close();
			System.out.println("Student record updated successfully.");

		} catch (StudentNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}// end of update method

	public static void displayRecord() {
		// Implement logic to display a student's details and result details
		try {
			Session session = DatabaseHandler.getDatabaseHandler().createSession();

			Scanner scanner = new Scanner(System.in);
			// Retrieve the student and result records from the database
			System.out.print("Enter Roll Number: ");
			String rollNumber = scanner.nextLine();

			Student student = session.get(Student.class, rollNumber);

			if (student == null) {
				throw new StudentNotFoundException("Student with Roll Number " + rollNumber + " not found.");
			}

			Result result = session.get(Result.class, rollNumber);
			System.out.println("Student Details:");
			System.out.println("Roll Number: " + student.getRollNumber());
			System.out.println("Student Name: " + student.getStudentName());
			System.out.println("Semester: " + student.getSemester());
			System.out.println("\nResult Details:");
			System.out.println("Half-Yearly Total: " + result.getHalfYearlyTotal());
			System.out.println("Annual Total: " + result.getAnnualTotal());
			System.out.println("Grade: " + result.getGrade());

			session.close();
		} catch (StudentNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	// Main Method
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("Menu:");
			System.out.println("1. Student Entry");
			System.out.println("2. Result Update");
			System.out.println("3. Show Student");
			System.out.println("4. Exit");

			int choice = scanner.nextInt();
			scanner.nextLine(); // Consume newline

			switch (choice) {
			case 1:
				insertRecord();
				break;
			case 2:
				updateRecord();
				break;
			case 3:
				displayRecord();
				break;
			case 4:
				System.out.println("Exiting the program.");
				System.exit(0);
			default:
				System.out.println("Invalid choice. Please try again.");
			}// end of Switch
		} // end of loop
	}// end of main method
}// end of class

