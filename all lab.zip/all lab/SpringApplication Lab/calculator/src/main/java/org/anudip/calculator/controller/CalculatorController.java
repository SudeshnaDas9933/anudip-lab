package org.anudip.calculator.controller;
import org.anudip.calculator.service.CalculatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@RestController
public class CalculatorController {
		@Autowired
	CalculatorService cService;

		@GetMapping("/calculatorEntry")
		public ModelAndView showCalculatorEntryPage() {
			ModelAndView mv = new ModelAndView("calculatorEntry");
			return mv;
		}

		@GetMapping("/calculatorResult")
		public ModelAndView showCalculatorResultPage() {
			return new ModelAndView("calculatorResult");
		}

		@PostMapping("/calculator")
	    public ModelAndView calculateResult(
	        @RequestParam String operand1,
	        @RequestParam String operand2,
	        @RequestParam String operator
	    ) {
	        int result = CalculatorService.performCalculation(operand1, operand2, operator);
	        
	        ModelAndView modelAndView = new ModelAndView("calculatorResult");
	        modelAndView.addObject("result", result);
	        
	        return modelAndView;
	}
}