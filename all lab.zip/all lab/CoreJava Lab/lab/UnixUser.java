package org.anudip.lab;
import java.util.Objects;
import java.util.Objects;

class UnixUser {
    private Integer userId;
    private Integer employeeId;
    private String username;
    private String userType;

    public UnixUser(Integer userId, Integer employeeId, String username, String userType) {
        this.userId = userId;
        this.employeeId = employeeId;
        this.username = username;
        this.userType = userType;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    @Override
    public String toString() {
    	return String.format("%-10s %-15s %-20s %-10s", userId, employeeId, username, userType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, employeeId, username, userType);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        UnixUser other = (UnixUser) obj;
        return Objects.equals(userId, other.userId) && Objects.equals(employeeId, other.employeeId)
                && Objects.equals(username, other.username) && Objects.equals(userType, other.userType);
    }
}
