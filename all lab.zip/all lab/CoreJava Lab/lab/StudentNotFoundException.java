package org.anudip.lab;

	class StudentNotFoundException extends RuntimeException {
	    public StudentNotFoundException(String message) {
	        super(message);
	    }
	}//end of class

