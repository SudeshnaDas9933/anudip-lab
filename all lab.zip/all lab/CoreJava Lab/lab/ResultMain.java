package org.anudip.lab;
import java.io.*;
import java.util.Scanner;

class ResultMain {
    private static StudentResult[] allStudents;
    private static int numberOfStudents;

    private static void convertToList() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader("d:/StudentResult.txt"))) {
            numberOfStudents = (int) reader.lines().count();
            allStudents = new StudentResult[numberOfStudents];

            int index = 0;
            try (BufferedReader innerReader = new BufferedReader(new FileReader("d:/StudentResult.txt"))) {
                String line;
                while ((line = innerReader.readLine()) != null) {
                    String trimmedLine = line.trim();
                    if (!trimmedLine.isEmpty()) {
                        String[] data = trimmedLine.split("-");
                        if (data.length >= 3) {
                            String rollNumber = data[0].trim();
                            String studentName = data[1].trim();
                            Double halfYearlyTotal = Double.parseDouble(data[2].trim());
                            allStudents[index++] = new StudentResult(rollNumber, studentName, halfYearlyTotal);
                        } else {
                            System.out.println("Invalid data format: " + line);
                        }
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        try {
            convertToList();
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Roll Number to update (or type 'exit' to stop): ");
            String searchRoll = scanner.nextLine();

            while (!searchRoll.equalsIgnoreCase("exit")) {
                StudentResult studentToUpdate = null;
                for (StudentResult student : allStudents) {
                    if (student.getRollNumber().trim().equals(searchRoll.trim())) {
                        studentToUpdate = student;
                        break;
                    }
                }

                if (studentToUpdate == null) {
                    System.out.println("Student with roll number " + searchRoll + " not found.");
                } else {
                    System.out.print("Enter marks for English: ");
                    double english = scanner.nextDouble();
                    System.out.print("Enter marks for Language: ");
                    double language = scanner.nextDouble();
                    System.out.print("Enter marks for Mathematics: ");
                    double mathematics = scanner.nextDouble();
                    System.out.print("Enter marks for Science: ");
                    double science = scanner.nextDouble();
                    System.out.print("Enter marks for Social Study: ");
                    double socialStudy = scanner.nextDouble();

                    double annualTotal = english + language + mathematics + science + socialStudy;
                    studentToUpdate.setAnnualTotal(annualTotal);

                    String grade = ResultService.gradeCalculation(studentToUpdate);
                    studentToUpdate.setGrade(grade);
                }

                // Consume the newline character after reading the roll number input
                scanner.nextLine();

                System.out.print("Enter Roll Number to update (or type 'exit' to stop): ");
                searchRoll = scanner.nextLine();
            }

            // After updating grades for all students

            try (FileWriter fileWriter = new FileWriter("d:/StudentResult.txt");
                 BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

                for (int j = 0; j < numberOfStudents; j++) {
                    bufferedWriter.write(allStudents[j].toString());
                    bufferedWriter.newLine();
                }
            }

            System.out.println("File Updated");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//end of main
}//end of class
