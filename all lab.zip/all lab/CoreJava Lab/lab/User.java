package org.anudip.lab;
public class User {
    private String userId;
    private String password;
 // Constructor to initialize user with user ID and password
    public User(String userId, String password) {
        this.userId = userId;
        this.password = password;
    }
 // Getter for the user's ID
    public String getUserId() {
        return userId;
    }
 // Setter for the user's ID
    public void setUserId(String userId) {
        this.userId = userId;
    }
 // Getter for the user's password
    public String getPassword() {
        return password;
    }
 // Setter for the user's password
    public void setPassword(String password) {
        this.password = password;
    }
}//end of class
