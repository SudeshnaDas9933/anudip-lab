package org.anudip.lab;
public class PermanentEmployee extends Employee {
    private Double monthlySalary;
    private Double pf;
    private Double tax;
    private static int idGen=1000;
    
	public PermanentEmployee(String employeeId, String employeeName, String department,Double monthlySalary, Double pf) {
		super(employeeId, employeeName, department);
		this.monthlySalary = monthlySalary;
		this.pf = pf;
		this.tax=this.calculateTax();
		
	}
	public Double getMonthlySalary() {
		return monthlySalary;
	}
	public void setMonthlySalary(Double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}
	public Double getPf() {
		return pf;
	}
	public void setPf(Double pf) {
		this.pf = pf;
	}
	public Double getTax() {
		return tax;
	}
	public void setTax(Double tax) {
		this.tax = tax;
	}
	public static int getIdGen() {
		return idGen;
	}
	public static void setIdGen(int idGen) {
		PermanentEmployee.idGen = idGen;
	}
	
	@Override
	public double calculateTax() {
		double empTax=(monthlySalary*12)*0.1;
		return empTax;
	}
	@Override
	public String toString() {
		return String.format("%-10s %-20s %-15s %-10s %-10s %-10s",
               getEmployeeId(), getEmployeeName(), getDepartment(),
               monthlySalary,pf,tax);
	}
	
	public static int generateId() {
	return	++idGen;
	}
	
	
}
