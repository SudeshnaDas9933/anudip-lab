package org.anudip.lab;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserApplication {
	// List to store user objects
    private List<User> userList = new ArrayList<>();
    // Method to upload user data from a file to the list
    public void uploadToList() {
        try (BufferedReader reader = new BufferedReader(new FileReader("d:/UserMaster.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    userList.add(new User(parts[0], parts[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading UserMaster.txt: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
    	 // Creating an instance of UserApplication
        UserApplication userApplication = new UserApplication();
     // Uploading user data from the file to the list
        userApplication.uploadToList();

        Scanner scanner = new Scanner(System.in);
     // Prompting the user for user ID and password
        System.out.print("Enter User Id: ");
        String userId = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
     // Variable to track user validation
        boolean validUser = false;
     // Iterating through the user list to validate user credentials
        for (User user : userApplication.userList) {
            if (user.getUserId().equals(userId) && user.getPassword().equals(password)) {
                validUser = true;
                break;
            }
        }
     // Displaying validation result
        if (validUser) {
            System.out.println("Valid User");
        } else {
            System.out.println("Invalid User");
        }
    }//end of main
}//end of class

