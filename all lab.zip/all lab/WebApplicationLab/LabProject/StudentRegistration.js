function validateForm() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    var nameError = document.getElementById("nameError");
    var emailError = document.getElementById("emailError");
    var passwordError = document.getElementById("passwordError");
    var confirmPasswordError = document.getElementById("confirmPasswordError");

    var namePattern = /^[a-zA-Z ]+$/;
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    nameError.textContent = "";
    emailError.textContent = "";
    passwordError.textContent = "";
    confirmPasswordError.textContent = "";

    if (!name.match(namePattern)) {
        nameError.textContent = "Invalid name. Please enter letters only.";
        return false;
    }

    if (!email.match(emailPattern)) {
        emailError.textContent = "Invalid email address.";
        return false;
    }

    if (password.length < 6) {
        passwordError.textContent = "Password must be at least 6 characters long.";
        return false;
    }

    if (password !== confirmPassword) {
        confirmPasswordError.textContent = "Passwords do not match.";
        return false;
    }

    return true;
}
/**
 * 
 */